import uuid
import datetime

class Todo:
    def __init__(self,text,sentiment="neutral",completed=False,id=str(uuid.uuid4()),
        date_created=str(datetime.date.today())) -> None:
        self.text = text
        self.sentiment = sentiment
        self.completed = completed
        self.id = id
        self.date_created = date_created

    def __str__(self) -> str:
        return f"{self.text},{self.sentiment},{self.completed},{self.id},{self.date_created}"

    def set_completed(self,is_completed) -> None:
        self.completed = is_completed