#imports
from flask import Flask, render_template, request, url_for, redirect
from AnalyseSentiment.AnalyseSentiment import AnalyseSentiment
from models.Todo import Todo
app = Flask(__name__)

images = {
    "Positive": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ56zxqEw3rqxm3ByviP4O9dmdbRh-nKzSEjjqKdyfe1hhfbasAzr1P7AiBmWJQmWg5Pcs&usqp=CAU",
    "Negative": "https://image.shutterstock.com/image-illustration/sad-depressed-emoji-face-600w-1485665696.jpg",
    "Neutral": "https://files.123freevectors.com/wp-content/original/33470-neutral-face-emoji.jpg"
}

"""
This function splits the todo string into
the components that can be used by the Todo
class.
"""
def extract_todos(todo) -> Todo:
    todo_parameters = todo.split(",")
    return Todo(
        todo_parameters[0],
        todo_parameters[1],
        todo_parameters[2],
        todo_parameters[3],
        todo_parameters[4]
    )
"""
Extracts the todo strings from the text file and
returns a list of all the todos.
"""
def get_todos() -> list:
    todos_file = open("todos.txt","r")
    todos_list = list(map(extract_todos,todos_file.read().split("\n")))
    todos_file.close()
    return todos_list
"""
Saves the provided todo in the text file
"""
def save_todo(todo) -> None:
    todos_file = open("todos.txt","a")
    todos_file.write(f"\n{str(todo)}")
    todos_file.close()


@app.route("/")
def home():
    todos_list = get_todos()
    return render_template("index.html", todo_list=todos_list, images=images)

@app.route("/create", methods=["POST"])
def create_todo():
    todo = Todo(request.form["text"])
    obj = AnalyseSentiment()
    todo.sentiment = obj.Analyse(todo.text)["overall_sentiment"]
    save_todo(todo)
    return redirect(url_for("home"))

@app.route("/set-completed", methods=["POST"])
def set_todo_completed():
    todo_id = request.form["id"]
    todos_list = get_todos()
    try:
        todo = list(filter(lambda id: id == todo_id),todos_list)[0]
        todo.completed = not todo.completed
        save_todo(todo)
        return redirect(url_for("home"))
    except:
        return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")