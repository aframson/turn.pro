const form = document.querySelector("#input-form");

form.addEventListener("submit", (e) => {
    e.preventDefault();
    console.log(form.input.value)
});